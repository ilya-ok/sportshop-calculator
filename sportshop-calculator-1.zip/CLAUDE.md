# Sportshop Calculator — контекст для Claude

## Что это

WordPress-плагин для расчёта материалов искусственного газона (спортивных покрытий).
Работает в двух режимах:
- **Страница товара** — калькулятор вставляется как таб через action-хук, данные о рулоне берутся из атрибутов текущего товара WooCommerce
- **Страница категории** — калькулятор вставляется шорткодом `[ssc_calculator id="calc_xxx"]`, пользователь выбирает подкатегорию, фильтрует по атрибутам и выбирает товар через Magnific Popup

### Поток пользователя в режиме категории

1. **Выбор подкатегории** — пользователь выбирает подкатегорию из выпадающего списка
2. **Загрузка атрибутов** — AJAX `ssc_load_subcategory_attrs` — загружаются захардкоженные атрибуты товаров этой подкатегории (высота ворса → толщина волокна → количество стежков), рендерятся как чекбоксы
3. **Фильтрация и загрузка товаров** — AJAX `ssc_load_products` с `subcategory_slug` + выбранные фильтры; сервер возвращает `available_filters` для динамического дизейбла чекбоксов
4. **Выбор товара** — кнопка `.ssc-select-product-btn` открывает Magnific Popup со списком карточек; клик по карточке закрывает popup и подставляет параметры рулона
5. **Расчёт** — пользователь вводит размеры площадки и получает расчёт
6. **КП** — форма → email + PDF через pdfMake

## Структура файлов

```
sportshop-calculator/
├── sportshop-calculator.php       # Главный файл: константы, хелперы, CRUD функции, регистрация AJAX-хуков
├── includes/
│   ├── class-ssc-admin.php        # Админ-панель: список калькуляторов, форма настройки, AJAX
│   └── class-ssc-frontend.php     # Фронтенд: шорткод, рендер, AJAX-обработчики
└── assets/
    ├── css/
    │   ├── calculator.css         # Стили калькулятора на фронтенде
    │   └── admin.css              # Стили админки
    ├── js/
    │   ├── calculator.js          # Логика расчёта, canvas, PDF на фронтенде
    │   └── admin.js               # JS для формы настройки в админке
    └── pdfmake/
        ├── pdfmake.min.js         # Генерация PDF
        └── vfs_fonts.js           # Шрифты для pdfMake (Roboto)
```

## Структура данных калькулятора (опция `ssc_calculators` в wp_options)

```php
[
    'id'                => 'calc_xxx',
    'name'              => 'Название',
    'category_slug'     => 'slug-kategorii',
    'subcategory_slugs' => ['dlya-futbola', 'dlya-mini-futbola'],  // slug подкатегорий для выбора на фронтенде
    'canvas_images'     => [                                        // изображения для подкатегорий (относит. пути)
        'dlya-futbola' => '/wp-content/uploads/field-football.jpg',
        'dlya-tennisa' => '/wp-content/uploads/field-tennis.jpg',
    ],
    'canvas_image'      => '/wp-content/uploads/field-default.jpg', // изображение по умолчанию (относит. путь)
    'hook_name'         => 'ssc_calc_slug_kategorii',               // для action-хука на странице товара
    'width_attr'        => 'shirina-rulona',                        // slug атрибута (без pa_)
    'length_attr'       => 'dlina-rulona',
    'filter_attrs'      => ['vysota-vorsa', 'cvet'],                // атрибуты для карточек товаров (превью)
    'glue_price'        => 4000,                                     // руб за банку 10 кг
    'tape_price'        => 65,                                       // руб за м.п.
    'sand_enabled'      => true,
    'sand_price'        => 3950,                                     // руб за тонну
    'rubber_enabled'    => true,
    'rubber_price'      => 24500,                                    // руб за тонну
    'markup_enabled'    => true,                                     // показывать выбор типа разметки
    'markup_percent'    => 0,                                        // устаревшее поле, не используется
    'admin_email'       => 'email@example.com',
    'company_name'      => 'Название компании',
]
```

**Важно про `canvas_images`:** пути хранятся относительными (`/wp-content/uploads/...`). На фронтенде конвертируются в абсолютные через `make_absolute_url()` / `make_absolute_urls()`.

**Важно про `filter_attrs`:** используется ТОЛЬКО для превью атрибутов в карточках товаров (`ajax_load_products`). Сами фильтры-чекбоксы берутся из захардкоженного списка `$attr_definitions`, а не из `filter_attrs`.

## Ключевые хелперы (sportshop-calculator.php)

```php
ssc_split_attr_values($raw)
// Разбивает строку атрибута WooCommerce на массив значений.
// Разделители: «|» или «, » (запятая+пробел).
// НЕ разбивает одиночную запятую в «1,8» (десятичный разделитель).
// Пример: "2 м, 4 м" → ["2 м", "4 м"];  "1,8 м" → ["1,8 м"]

ssc_attr_float($val)
// Возвращает float из строки атрибута. Убирает единицы, заменяет «,» на «.»
// Пример: "40 мм" → 40.0;  "1,8 м" → 1.8

ssc_attr_display($val)
// Убирает суффикс «м»/«мм» для отображения в кнопке.
// Пример: "1,8 м" → "1,8";  "40 мм" → "40"
```

> **Важно:** WooCommerce возвращает атрибуты через `$product->get_attribute('pa_slug')` как строку «значение1, значение2». Десятичные числа пишутся через запятую («1,8 м»). Нельзя использовать `explode(',', ...)` или `/[\s,|]+/` — сломает парсинг.

## Методы SSC_Frontend (class-ssc-frontend.php)

### Private helpers

```php
make_absolute_url($url): string
// Если $url начинается с http — возвращает как есть.
// Если относительный путь (/wp-content/...) — добавляет home_url().
// Пример: "/wp-content/uploads/a.jpg" → "http://site.ru/wp-content/uploads/a.jpg"

make_absolute_urls($images): array
// То же самое для массива canvas_images: ['slug' => '/path/...']
```

### Рендер

- `render_shortcode($atts)` — точка входа шорткода, вызывает `render_category_calculator()`
- `render_category_calculator($calc)` — полный рендер режима категории (select подкатегорий + filter step + параметры рулона + разметка + размеры + canvas + результаты + форма КП + кнопка тест-PDF)
- `render_product_calculator($calc, $product_id)` — оболочка для страницы товара, вызывает `render_calculator_core()`
- `render_calculator_core($calc, $product)` — параметры рулона + разметка + размеры + canvas + результаты + форма КП (без кнопки тест-PDF)

## Расчётные формулы (calculator.js)

### Количество рулонов (шахматный раскрой)
```
rollCount = ceil((area + markupArea) / (rW × rL))
```

### Горизонтальные стыки
```
stripsCount = ceil(W / rW)
hSeamsCount = stripsCount - 1
hSeamLen    = hSeamsCount × L
```

### Вертикальные стыки (шахматный сдвиг)
- Нечётные полосы: первый шов на `rL`, затем через `rL`
- Чётные полосы: первый шов на `rL/2`, затем через `rL`
- **Если `rL >= L` — вертикальных швов нет** (canvas их тоже не рисует)

```js
if (rL < L) {
    xi = rL;      while (xi < L) { styk_odd++;  xi += rL; }
    xi = rL / 2;  while (xi < L) { styk_even++; xi += rL; }
}
```

### Клей и шовная лента (с учётом линий разметки)
```
effectiveSeamLen = totalSeamLen + markupCount   // markupCount = 0 если разметка не выбрана
glueKg           = effectiveSeamLen × 0.5 × 1.05
glueCount        = ceil(glueKg / 10)            // банок по 10 кг
tapeMeters       = effectiveSeamLen × 1.05      // + 5% на подрез
```

### Кварцевый песок и резиновая крошка

Плотность зависит от высоты ворса (мм). `h` берётся из `product.height` (атрибут `pa_vysota-vorsa`).

| Высота (h) | Песок (кг/м²) | Крошка (кг/м²) |
|-----------|--------------|----------------|
| 10–12     | 7.8          | 0              |
| 14–15     | 10           | 0              |
| 20        | 4.8          | 3              |
| 25        | 6            | 4              |
| 30        | 7.5          | 5              |
| 32–35     | 9            | 6              |
| 40        | 12           | 7              |
| 45        | 20           | 8              |
| 50        | 22           | 9              |
| 55        | 22           | 10.5           |
| 60        | 22           | 12             |

```
sandKg   = Math.round(area × sandDensity(h))
rubberKg = Math.round(area × rubberDensity(h))
sandCost   = (sandKg / 1000) × sandPrice
rubberCost = (rubberKg / 1000) × rubberPrice
```

### Разметка поля (4 типа)

`L` = длина площадки, `W` = ширина площадки.

| Тип            | markupCount (м.п.)                                    | ширина полосы |
|----------------|-------------------------------------------------------|---------------|
| Футбол         | `L×2 + W×3 + 314`                                    | 0.10 м        |
| Мини-футбол    | `L×2 + W×3 + 65`                                     | 0.08 м        |
| Теннис         | `L×4 + W×2 + W + 1.73 + (W-2.74)×2 + 12.85`         | 0.05 м        |
| Хоккей         | `L×2 + W×5 + 121`                                    | 0.075 м       |

```
rawMarkupArea = markupCount × ширина_полосы
markupArea    = Math.ceil(rawMarkupArea × 1.03)   // +3% на подрез
totalGrassArea = area + markupArea
grassCost      = totalGrassArea × price
```

Линии разметки добавляются к шву для клея и ленты (`effectiveSeamLen`).

### Площадь
Площадь всегда округляется через `Math.round()` (не toFixed).

## AJAX-обработчики

### Фронтенд (class-ssc-frontend.php + sportshop-calculator.php)

| action | nonce | где зарегистрирован | описание |
|--------|-------|---------------------|----------|
| `ssc_load_subcategory_attrs` | `ssc_frontend_nonce` | `sportshop-calculator.php` (глобально) | Загрузить атрибуты выбранной подкатегории (HTML фильтров + filter_attrs для JS) |
| `ssc_load_products` | `ssc_frontend_nonce` | `SSC_Frontend::__construct()` | Загрузить товары подкатегории с фильтрацией; возвращает HTML + available_filters |
| `ssc_send_kp` | `ssc_frontend_nonce` | `SSC_Frontend::__construct()` | Отправить заявку КП на email |

> **Важно:** `ssc_load_subcategory_attrs` зарегистрирован в `sportshop-calculator.php` (не в конструкторе SSC_Frontend), чтобы избежать конфликта singleton с одноимённым методом в классе (вызывает `SSC_Frontend::get_instance()->ajax_load_category_attrs()`).

### Админка (class-ssc-admin.php)

| action | nonce | описание |
|--------|-------|----------|
| `ssc_load_category_attrs` | `ssc_admin_nonce` | Загрузить атрибуты родительской категории (для select'ов в форме) |
| `ssc_save_calculator` | `ssc_admin_nonce` | Сохранить/создать калькулятор |
| `ssc_delete_calculator` | `ssc_admin_nonce` | Удалить калькулятор |
| `ssc_get_calculator` | `ssc_admin_nonce` | Получить данные калькулятора для редактирования |

### Захардкоженные атрибуты фильтрации

В `ajax_load_category_attrs()` (фронтенд) и `ajax_load_products()` используется одинаковый `$attr_definitions`:

```php
$attr_definitions = [
    'vysota-vorsa'         => 'pa_vysota-vorsa',
    'tolshhina-volokna'    => 'pa_tolshhina-volokna',
    'kolichestvo-stezhkov' => 'pa_kolichestvo-stezhkov',
];
```

Порядок строго фиксирован. `filter_attrs` из настроек калькулятора игнорируется для фильтров-чекбоксов.

### Динамическое дизейбливание фильтров

`ajax_load_products` возвращает `available_filters` — для каждого атрибута массив slug'ов доступных значений по текущим товарам. JS `updateFilterAvailability()` добавляет `.ssc-filter-check--disabled` (opacity 0.4, pointer-events none) на недоступные чекбоксы.

## Конфиг JS (data-config на .ssc-calculator)

```json
{
    "id": "calc_xxx",
    "mode": "product | category",
    "categorySlug": "iskusstvennyj-gazon",
    "subcategorySlugs": ["dlya-futbola", "dlya-tennisa"],
    "canvasImages": {
        "dlya-futbola": "https://site.ru/wp-content/uploads/football.jpg"
    },
    "canvasImage": "https://site.ru/wp-content/uploads/default.jpg",
    "widthAttr": "shirina-rulona",
    "lengthAttr": "dlina-rulona",
    "filterAttrs": ["vysota-vorsa", "cvet"],
    "gluePrice": 4000,
    "tapePrice": 65,
    "sandEnabled": true,
    "sandPrice": 3950,
    "rubberEnabled": true,
    "rubberPrice": 24500,
    "markupEnabled": true,
    "companyName": "...",
    "siteDate": "01.01.2026",
    "product": {
        "id": 123,
        "name": "Название товара",
        "price": 500,
        "widths": [2, 4],
        "lengths": [20, 40],
        "length": 20,
        "defaultWidth": 2,
        "defaultLength": 20,
        "height": 40
    }
}
```

`product` присутствует только в режиме `product`. В режиме `category` = `null`.
`canvasImages` и `canvasImage` — уже абсолютные URL (конвертированы PHP-методами).

## Режим category (страница категории)

- **Шаг 0 `.ssc-step--subcategory`** — PHP рендерит `<select class="ssc-subcategory-select">` с подкатегориями из `subcategory_slugs`. Только существующие в базе.
- **Шаг 1 `.ssc-step--filter`** — скрыт по умолчанию. JS показывает после выбора подкатегории. Внутри: `.ssc-filter-wrap` + `.ssc-select-product-btn` + скрытый `.ssc-products-list`.
- **Кнопка выбора** `.ssc-select-product-btn` открывает Magnific Popup с `.ssc-products-list`.
- **Шаг 2** — список товаров загружается AJAX `ssc_load_products` с фильтрами. Ответ: HTML карточек + available_filters.
- `onProductSelected()` вызывается после клика по карточке; перерисовывает ширины/длины, запускает `calculate()`.

### Структура кнопки выбора покрытия

```html
<button class="ssc-select-product-btn" id="ssc-select-product-btn-{id}">
    <span class="ssc-select-product-btn__label">
        <span class="ssc-select-product-btn__text">Выберите покрытие</span>
        <span class="ssc-select-product-btn__count" id="ssc-product-count-{id}">0</span>
    </span>
    <span class="ssc-select-product-btn__arrow"></span>
</button>
```

`.ssc-btn--loading` — класс во время загрузки товаров: repeating-linear-gradient shimmer через `::before`, `pointer-events: none`.

## Режим product (страница товара)

- PHP рендерит радио-кнопки ширины/длины сразу в HTML (без AJAX)
- JS в `init()` читает уже отрендеренные `input[name="ssc_width_{calcId}"]`
- `onProductSelected()` не вызывается
- Нет кнопки «Скачать PDF (тест)»

## CSS-классы (ключевые)

| Класс | Элемент |
|-------|---------|
| `.ssc-calculator` | корневой контейнер, `max-width: 1100px; margin: 0 auto` |
| `.ssc-step` | секция-шаг: `display: flex; align-items: flex-start; gap: 16px` |
| `.ssc-section-title` | заголовок шага: `width: 200px; text-align: right; white-space: nowrap; flex-shrink: 0` + `::after {content:':'}` |
| `.ssc-step__content` | обёртка контента: `flex: 1; max-width: 900px; min-width: 0` |
| `.ssc-step--subcategory` | выбор подкатегории |
| `.ssc-step--filter` | фильтры + кнопка выбора товара (скрыт по умолчанию) |
| `.ssc-subcategory-select` | select подкатегории |
| `.ssc-select-product-btn` | кнопка выбора покрытия (`border: 2px solid #8bc73f; max-width: 600px`) |
| `.ssc-btn--loading` | shimmer-анимация на кнопке во время загрузки |
| `.ssc-products-list` | список карточек в Magnific Popup |
| `.ssc-product-card` | карточка товара в 1 строку: img 30×30px → название → атрибуты → цена |
| `.ssc-filter-check--disabled` | дизейблед чекбокс фильтра (`opacity: 0.4; pointer-events: none`) |
| `.ssc-radio-btn` | кнопка выбора ширины/длины/разметки |
| `.ssc-radio-btn--active` | активная кнопка |
| `.ssc-counter` | счётчик +/− (шаг = 1) |
| `.ssc-canvas-wrap` | обёртка canvas `max-width: 600px`, содержит `.ssc-canvas-bg` + `.ssc-canvas` |
| `.ssc-canvas-bg` | фоновое изображение (HTML img, z-index под canvas) |
| `.ssc-canvas` | canvas раскладки 730×365, прозрачный |
| `.ssc-products-list` | контейнер карточек внутри Magnific Popup: `max-height: 600px; overflow-y: auto` |
| `.ssc-step--active` | модификатор, добавляемый JS к `.ssc-step--roll`, `.ssc-step--dims`, `.ssc-step--results` после выбора товара/ввода размеров |
| `.ssc-step--markup` | выбор типа разметки — расположен **после** `.ssc-step--dims` (не до) |
| `.ssc-markup-type-list` | flex-контейнер кнопок разметки |
| `.ssc-markup-icon` | иконка внутри кнопки разметки: `img` 17×17px или `span` с ✕ для «Без разметки» |
| `.ssc-markup-icon--none` | крестик ✕ для «Без разметки»; зелёный при активном состоянии |
| `.ssc-result-row` | строка результата |
| `.ssc-res-seams` | длина швов рулонов (гор. + верт.), всегда видна |
| `.ssc-res-row-markup-seams` | строка «Разметка: X м.п.» — скрыта по умолчанию, показывается JS если выбран тип разметки |
| `.ssc-res-seams-markup` | val-спан строки разметки |
| `.ssc-res-total` | итоговая сумма |
| `.ssc-glue-check` | чекбокс «добавить клей» (выключен по умолчанию) |
| `.ssc-tape-check` | чекбокс «добавить шовную ленту» (выключен по умолчанию) |
| `.ssc-sand-check` | чекбокс «добавить песок» |
| `.ssc-rubber-check` | чекбокс «добавить крошку» |

На мобильных (≤768px): `.ssc-step` переключается в `flex-direction: column`, заголовок выравнивается влево.

**Акцентный цвет `#8bc73f`** — используется глобально: активные радио-кнопки и чекбоксы фильтров, активные карточки товаров, цена товара, площадь в результатах, кнопки КП и отправки, `accent-color` чекбоксов, граница итого. Hover: `#6fa32e`. Фон активных элементов: `#eef5e0` / `#f0f5e6`.

## Кеширование

Все данные фронтенд-запросов кешируются через WordPress Transient (`ssc_calc_cache`, время жизни `DAY_IN_SECONDS` = 24 часа).

### Что кешируется

1. **Атрибуты подкатегории** — ключ `attrs_{subcategory_slug}`. Хранит HTML фильтров + `filter_attrs`.
2. **Список товаров** — ключ `md5(category_slug + JSON(отсортированных фильтров))`. Хранит HTML карточек + `available_filters`.

### Автоматическая очистка

Transient удаляется при хуках:
- `save_post_product`, `edited_product_cat`, `created_product_cat`, `delete_product_cat`
- `created_/edited_/deleted_` для `pa_vysota-vorsa`, `pa_tolshhina-volokna`, `pa_kolichestvo-stezhkov`
- Кнопка «Очистить кеш» в админке и «Очистить кеш калькулятора» на фронтенде

### Отслеживание кеша (debug)

В каждый ответ AJAX добавляется поле `"source": "cache" | "db"`.
JS (`calculator.js`) выводит в консоль:
- 🟢 `[SSC] Товары загружены из кеша ⚡` или `[SSC] Товары загружены из базы данных`
- 🔵 `[SSC] Атрибуты загружены из кеша ⚡` или `[SSC] Атрибуты загружены из базы данных`

### Приватные методы кеширования (SSC_Frontend)

```php
get_cache(): array          // Возвращает массив из transient, либо {attrs:[], products:[]}
save_cache($data): void     // set_transient(..., DAY_IN_SECONDS)
```

## Известные особенности / ловушки

1. **Захардкоженный slug высоты ворса** — `pa_vysota-vorsa` в `get_calc_js_config()` и в `$attr_definitions`. Если slug отличается — `height: 0`, песок/крошка не считаются, фильтр не появится.

2. **`ssc_load_subcategory_attrs` vs `ssc_load_category_attrs`** — фронтенд AJAX-экшн называется `ssc_load_subcategory_attrs`. Метод класса называется `ajax_load_category_attrs()`. Это одна и та же функция, зарегистрированная с разными именами для фронтенда (через глобальную функцию в main файле) и не пересекающаяся с admin-экшном `ssc_load_category_attrs`.

3. **Canvas** рисует шахматную раскладку рулонов. Ось X = длина (L), ось Y = ширина (W). При `rL >= L` вертикальные линии не рисуются. Canvas прозрачный (`ctx.clearRect`), фоновое изображение — HTML `<img>` под ним.

4. **pdfMake** подключается из `assets/pdfmake/`. Fallback: тема — `/pdfmake/pdfmake.min.js`. Magnific Popup: тема — `/assets/js/jquery.magnific-popup.min.js`, fallback — CDN.

5. **`markup_percent`** — устаревшее поле в БД, сохраняется, не используется. Стоимость разметки = `markupArea × grassPrice` (тот же продукт).

6. **`filter_attrs`** — хранится в настройках, но для фильтров-чекбоксов НЕ используется. Только для превью атрибутов в карточках товаров (без `vysota-vorsa`, только значения без меток).

7. **canvas_images** — пути хранятся относительными. PHP конвертирует при передаче в JS-конфиг через `make_absolute_url()`. JS дополнительно страхуется: `imgUrl.indexOf('http') === 0 ? imgUrl : g.siteUrl + imgUrl`.

8. **Кнопка «Скачать PDF (тест)»** — есть только в `render_category_calculator()`. В `render_calculator_core()` (страница товара) её нет.

9. **`array_values()` для PHP-массивов атрибутов** — при формировании `available_filters` каждый массив значений прогоняется через `array_values()`, чтобы JSON-энкодер отдал `[]` вместо объекта `{}`. Без этого JS получит `{"0":"val"}` вместо `["val"]` и `indexOf()` сломается.

10. **Админка — динамические поля `canvas_images`** — `admin.js` слушает изменения в textarea `subcategory_slugs`. При каждом изменении парсит slug'и по строкам и динамически рендерит для каждого поле: label с именем подкатегории, input URL, кнопка выбора из медиа-библиотеки, превью. Поля появляются в блоке `.ssc-canvas-images-wrap`.

11. **Результаты — строки:**
   - Площадь: `Math.round()` (не toFixed)
   - Клей: `X банок - Y кг (~Z руб.)` (кг через тире, не в скобках)
   - Лента: `X м.п. в т.ч. + 5% на подрез (~Z руб.)`
   - Песок/крошка: `X кг (~Z руб.)`
   - Длина швов разбита на две строки: `.ssc-res-seams` (рулонные швы) + `.ssc-res-row-markup-seams` (м.п. разметки, только при выбранном типе)
   - Строка «в т.ч. материал разметки (+3%)» удалена из UI (расчёт сохранён)

12. **Чекбоксы доп. материалов** — `.ssc-result-val` в строках клея, ленты, песка, крошки скрыт по умолчанию (`display:none` в PHP). Управляется методом `syncCheckboxRows()`, который вызывается при каждом пересчёте (`updateResultsUI`) и при смене чекбокса.

13. **Иконки в кнопках разметки** — изображения из `/wp-content/calculator/`: `football.png`, `mini-football.png`, `tennis.png`, `hockey.png`. Для «Без разметки» — `<span class="ssc-markup-icon ssc-markup-icon--none">✕</span>`. Текст каждой кнопки обёрнут в `<span>`. URL формируется через `home_url('/wp-content/calculator/')` в PHP.
