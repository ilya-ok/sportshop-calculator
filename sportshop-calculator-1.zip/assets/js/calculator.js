/* ==========================================================================
   SSC Frontend Calculator JS
   canvas + расчёт + PDF
   ========================================================================== */
(function ($) {
    'use strict';

    var g = window.sscCalc || {};

    /* =========================================================================
       Экземпляр калькулятора
       ========================================================================= */
    function SSCInstance($wrap) {
        this.$wrap     = $wrap;
        this.config    = JSON.parse($wrap.attr('data-config') || '{}');
        this.calcId    = $wrap.attr('data-calc-id');
        this.product   = this.config.product || null; // null = режим категории
        this.rollWidth  = this.product ? (this.product.defaultWidth || 0) : 0;
        this.rollLength = this.product ? (this.product.defaultLength || 0) : 0;
        this.areaLen    = 0;
        this.areaWid    = 0;
        this.$canvas    = $wrap.find('.ssc-canvas');
        this.ctx        = this.$canvas.length ? this.$canvas[0].getContext('2d') : null;
        this.bgImage    = null;
        this._lastCalc  = null;

        this.init();
    }

    SSCInstance.prototype = {

        init: function () {
            var self = this;

            // Текущая выбранная подкатегория
            this.selectedSubcategory = null;
            // Текущие фильтры-атрибуты категории
            this.categoryFilterAttrs = [];

            this.bindEvents();

            // Режим категории — ждём выбора подкатегории, показываем дефолтное изображение
            if (this.config.mode === 'category') {
                // resetFilterStep не вызываем — блок уже виден с плейсхолдером из PHP
                this.updateCanvasBg();
            }

            // Режим товара — PHP уже отрисовал радио-кнопки ширины и длины; просто читаем значения
            if (this.config.mode === 'product' && this.product) {
                var $checkedWidth = this.$wrap.find('input[name="ssc_width_' + this.calcId + '"]:checked');
                this.rollWidth = $checkedWidth.length ? parseFloat($checkedWidth.val()) : (this.product.defaultWidth || 0);
                var $checkedLength = this.$wrap.find('input[name="ssc_length_' + this.calcId + '"]:checked');
                this.rollLength = $checkedLength.length ? parseFloat($checkedLength.val()) : (this.product.defaultLength || 0);
                this.$wrap.find('.ssc-form-product-name').val(this.product.name || '');
                this.calculate();
            }
        },

        /* -------------------------------------------------------------------
           Привязка событий
           ------------------------------------------------------------------- */
        bindEvents: function () {
            var self = this;

            // Выбор подкатегории (категория)
            this.$wrap.on('change', '.ssc-subcategory-select', function () {
                var subcatSlug = $(this).val();
                if (subcatSlug) {
                    self.selectedSubcategory = subcatSlug;
                    self.loadCategoryAttrs();
                } else {
                    self.selectedSubcategory = null;
                    self.resetFilterStep();
                }
            });

            // Фильтры (категория) — динамически загруженные
            this.$wrap.on('change', '.ssc-filter-cb', function () {
                // Дизейблим все остальные группы атрибутов на время загрузки
                self.$wrap.find('.ssc-filter-attr').each(function () {
                    var $group = $(this);
                    var hasChecked = $group.find('.ssc-filter-cb:checked').length > 0;
                    // Если в этой группе есть выбранный чекбокс — не трогаем, остальные — дизейблим
                    if (!hasChecked) {
                        $group.addClass('ssc-filter-attr--loading');
                    }
                });
                // Дизейблим текущую группу тоже (кроме изменённого чекбокса)
                $(this).closest('.ssc-filter-attr').find('.ssc-filter-cb').not(this).prop('disabled', true);
                self.loadProducts();
            });

            // Кнопка выбора покрытия — открывает Magnific Popup
            this.$wrap.on('click', '.ssc-select-product-btn', function () {
                var $popup = self.$wrap.find('#ssc-products-' + self.calcId);
                if (!$popup.children().length || $popup.find('.ssc-products-loading').length) return;
                $popup.css('display', 'block');
                $.magnificPopup.open({
                    items: { src: $popup },
                    type: 'inline',
                    midClick: true,
                    closeBtnInside: true,
                    closeOnBgClick: true,
                    mainClass: 'ssc-product-popup',
                    removalDelay: 300,
                    callbacks: {
                        close: function () {
                            $popup.hide();
                        }
                    }
                });
            });

            // Выбор товара (категория) — клик по карточке, т.к. popup перемещает элементы
            $(document).on('click', '.ssc-product-card', function (e) {
                e.preventDefault();
                var $radio = $(this).find('input[name="ssc_product_' + self.calcId + '"]');
                if ($radio.length && !$radio.prop('checked')) {
                    $radio.prop('checked', true);
                }
                var productData = JSON.parse($radio.attr('data-product') || 'null');
                if (productData) {
                    // Закрываем popup
                    $.magnificPopup.close();
                    // Обновляем текст кнопки
                    var $btn = self.$wrap.find('#ssc-select-product-btn-' + self.calcId);
                    $btn.find('.ssc-select-product-btn__text').text(productData.name);
                    // Подгружаем параметры рулона
                    self.onProductSelected(productData);
                }
            });

            // Выбор ширины рулона
            this.$wrap.on('change', 'input[name="ssc_width_' + this.calcId + '"]', function () {
                self.rollWidth = parseFloat($(this).val()) || 0;
                $(this).closest('.ssc-width-list').find('.ssc-radio-btn').removeClass('ssc-radio-btn--active');
                $(this).closest('.ssc-radio-btn').addClass('ssc-radio-btn--active');
                self.calculate();
            });

            // Выбор длины рулона (если несколько значений)
            this.$wrap.on('change', 'input[name="ssc_length_' + this.calcId + '"]', function () {
                self.rollLength = parseFloat($(this).val()) || 0;
                $(this).closest('.ssc-width-list').find('.ssc-radio-btn').removeClass('ssc-radio-btn--active');
                $(this).closest('.ssc-radio-btn').addClass('ssc-radio-btn--active');
                self.calculate();
            });

            // Размеры площадки — поля ввода
            this.$wrap.on('input change', '.ssc-area-length', function () {
                self.areaLen = parseFloat($(this).val()) || 0;
                self.calculate();
            });
            this.$wrap.on('input change', '.ssc-area-width', function () {
                self.areaWid = parseFloat($(this).val()) || 0;
                self.calculate();
            });

            // Счётчики +/–
            this.$wrap.on('click', '.ssc-counter__plus', function () {
                var $input = $(this).siblings('.ssc-counter__val');
                var val = parseFloat($input.val()) || 0;
                $input.val((val + 1).toFixed(0)).trigger('change');
            });
            this.$wrap.on('click', '.ssc-counter__minus', function () {
                var $input = $(this).siblings('.ssc-counter__val');
                var val = parseFloat($input.val()) || 0;
                var next = Math.max(0, val - 1);
                $input.val(next.toFixed(0)).trigger('change');
            });

            // Выбор типа разметки
            this.$wrap.on('change', 'input[name="ssc_markup_type_' + this.calcId + '"]', function () {
                $(this).closest('.ssc-markup-type-list').find('.ssc-radio-btn').removeClass('ssc-radio-btn--active');
                $(this).closest('.ssc-radio-btn').addClass('ssc-radio-btn--active');
                self.calculate();
            });

            // Чекбоксы доп. материалов
            this.$wrap.on('change', '.ssc-glue-check, .ssc-tape-check, .ssc-sand-check, .ssc-rubber-check', function () {
                self.syncCheckboxRows();
                self.updateTotals(self._lastCalc);
            });

            // Кнопка КП
            this.$wrap.on('click', '.ssc-kp-btn', function () {
                self.openModal();
            });

            // Кнопка теста PDF — сразу генерация без модалки
            this.$wrap.on('click', '.ssc-kp-test-btn', function () {
                if (!self._lastCalc || !self._lastCalc.area) {
                    alert('Сначала выполните расчёт');
                    return;
                }
                self.generatePDF();
            });

            // Закрыть модал
            this.$wrap.on('click', '.ssc-modal-close', function () {
                self.closeModal();
            });

            // Отправить форму
            this.$wrap.on('submit', '.ssc-kp-form', function (e) {
                e.preventDefault();
                self.submitKP($(this));
            });
        },

        /* -------------------------------------------------------------------
           Сбросить шаг фильтров к начальному состоянию
           ------------------------------------------------------------------- */
        resetFilterStep: function () {
            var $filterWrap = this.$wrap.find('#ssc-filter-wrap-' + this.calcId);
            var $filterContent = this.$wrap.find('#ssc-filter-content-' + this.calcId);
            var $filterPlaceholder = this.$wrap.find('#ssc-filter-placeholder-' + this.calcId);
            var $selectBtn = this.$wrap.find('#ssc-select-product-btn-' + this.calcId);
            var $list = this.$wrap.find('#ssc-products-' + this.calcId);

            // Показать плейсхолдер, скрыть контент
            if ($filterPlaceholder.length) $filterPlaceholder.show();
            if ($filterContent.length) $filterContent.hide();
            if ($selectBtn.length) $selectBtn.hide();
            if ($filterWrap.length) $filterWrap.html('');
            if ($list.length) {
                $list.html('<p class="ssc-products-loading">' + 'Выберите категорию для загрузки товаров' + '</p>').hide();
            }
            this.categoryFilterAttrs = [];
            this.selectedSubcategory = null;
            // Сброс кнопки
            var $btn = this.$wrap.find('#ssc-select-product-btn-' + this.calcId);
            if ($btn.length) {
                $btn.find('.ssc-select-product-btn__text').text('Выберите покрытие');
                $btn.find('#ssc-product-count-' + this.calcId).text('0');
            }
            this.updateCanvasBg();
        },

        /* -------------------------------------------------------------------
           Обновить фоновое изображение canvas для выбранной подкатегории
           ------------------------------------------------------------------- */
        updateCanvasBg: function () {
            var imgUrl = '';
            if (this.selectedSubcategory && this.config.canvasImages && this.config.canvasImages[this.selectedSubcategory]) {
                imgUrl = this.config.canvasImages[this.selectedSubcategory];
            }
            // Если для подкатегории нет изображения — используем изображение по умолчанию
            if (!imgUrl) {
                imgUrl = this.config.canvasImage || '';
            }
            var $wrap = this.$wrap.find('.ssc-canvas-wrap');
            var $bg = $wrap.find('.ssc-canvas-bg');
            if (imgUrl) {
                // Преобразуем относительный путь в полный URL
                var fullUrl = (imgUrl.indexOf('http') === 0) ? imgUrl : (g.siteUrl + imgUrl);
                if ($bg.length) {
                    $bg.attr('src', fullUrl);
                } else {
                    $wrap.prepend('<img class="ssc-canvas-bg" src="' + fullUrl + '" alt="">');
                }
            } else {
                $bg.remove();
            }
        },

        /* -------------------------------------------------------------------
           Загрузить атрибуты выбранной подкатегории
           ------------------------------------------------------------------- */
        loadCategoryAttrs: function () {
            var self = this;
            var $filterStep = this.$wrap.find('#ssc-filter-step-' + this.calcId);
            var $filterWrap = this.$wrap.find('#ssc-filter-wrap-' + this.calcId);
            var $filterContent = this.$wrap.find('#ssc-filter-content-' + this.calcId);
            var $filterPlaceholder = this.$wrap.find('#ssc-filter-placeholder-' + this.calcId);
            var $selectBtn = this.$wrap.find('#ssc-select-product-btn-' + this.calcId);
            var $list = this.$wrap.find('#ssc-products-' + this.calcId);

            // Показать контент, скрыть плейсхолдер
            if ($filterContent.length) $filterContent.show();
            if ($filterPlaceholder.length) $filterPlaceholder.hide();
            if ($selectBtn.length) $selectBtn.show();

            if ($list.length) {
                $list.html('<p class="ssc-products-loading">' + g.strings.loading + '</p>').hide();
            }

            // Меняем фон canvas на изображение выбранной подкатегории
            this.updateCanvasBg();
            // Сбрасываем счётчик товаров
            this.$wrap.find('#ssc-product-count-' + this.calcId).text('0');
            var $btn = this.$wrap.find('#ssc-select-product-btn-' + this.calcId);
            if ($btn.length) {
                $btn.find('.ssc-select-product-btn__text').text('Выберите покрытие');
            }

            $.post(g.ajaxUrl, {
                action: 'ssc_load_subcategory_attrs',
                nonce:   g.nonce,
                calc_id: this.calcId,
                subcategory_slug: this.selectedSubcategory
            }, function (res) {
                if (res.success) {
                    self.categoryFilterAttrs = res.data.filter_attrs || [];
                    if ($filterWrap.length) {
                        $filterWrap.html(res.data.filter_html);
                    }
                    // Показать заголовок фильтров если есть чекбоксы
                    var $filterTitle = self.$wrap.find('#ssc-filter-title-' + self.calcId);
                    if (res.data.filter_html.trim() && $filterTitle.length) {
                        $filterTitle.show();
                    } else {
                        $filterTitle.hide();
                    }
                    
                    // Отладка кеша
                    if (res.data.source === 'cache') {
                        console.log('%c[SSC] Атрибуты загружены из кеша ⚡', 'color: blue; font-weight: bold');
                    } else {
                        console.log('[SSC] Атрибуты загружены из базы данных');
                    }
                    
                    $filterStep.show();
                    self.loadProducts();
                } else {
                    if ($list.length) {
                        $list.html('<p class="ssc-no-products">' + (res.data || 'Ошибка загрузки') + '</p>');
                    }
                }
            }).fail(function (xhr) {
                console.log('loadCategoryAttrs failed:', xhr.status, xhr.responseText.substring(0, 500));
                if ($list.length) {
                    $list.html('<p class="ssc-no-products">Ошибка: ' + xhr.status + '</p>');
                }
            });
        },

        /* -------------------------------------------------------------------
           Загрузить список товаров (режим категории)
           ------------------------------------------------------------------- */
        loadProducts: function () {
            var self = this;
            var $list = this.$wrap.find('#ssc-products-' + this.calcId);
            if (!$list.length) return;

            var filters = {};
            this.$wrap.find('.ssc-filter-cb:checked').each(function () {
                var $cb  = $(this);
                var attr = $cb.closest('.ssc-filter-attr').data('attr');
                if (!filters[attr]) filters[attr] = [];
                filters[attr].push($cb.val());
            });

            // Показать анимацию загрузки на кнопке
            var $btn = this.$wrap.find('#ssc-select-product-btn-' + this.calcId);
            $btn.addClass('ssc-btn--loading');
            $list.html('<p class="ssc-products-loading">' + g.strings.loading + '</p>');

            $.post(g.ajaxUrl, {
                action: 'ssc_load_products',
                nonce:   g.nonce,
                calc_id: this.calcId,
                subcategory_slug: this.selectedSubcategory || '',
                filters: filters
            }, function (res) {
                // Снимаем блокировку с групп атрибутов
                self.$wrap.find('.ssc-filter-attr--loading').removeClass('ssc-filter-attr--loading');
                self.$wrap.find('.ssc-filter-attr .ssc-filter-cb').prop('disabled', false);

                // Убрать анимацию загрузки с кнопки
                $btn.removeClass('ssc-btn--loading');
                if (res.success) {
                    $list.html(res.data.html).hide();
                    // Обновляем счётчик товаров на кнопке
                    var count = $list.find('.ssc-product-card').length;
                    self.$wrap.find('#ssc-product-count-' + self.calcId).text(count);
                    
                    // Отладка кеша
                    if (res.data.source === 'cache') {
                        console.log('%c[SSC] Товары загружены из кеша ⚡', 'color: green; font-weight: bold');
                        $btn.attr('data-source', 'cache');
                    } else {
                        console.log('[SSC] Товары загружены из базы данных');
                        $btn.removeAttr('data-source');
                    }
                    
                    // Закрываем popup если он открыт
                    $.magnificPopup.close();
                    // Обновляем доступные фильтры
                    if (res.data.available_filters) {
                        self.updateFilterAvailability(res.data.available_filters);
                    }
                }
            }).fail(function () {
                // При ошибке тоже снимаем блокировку
                self.$wrap.find('.ssc-filter-attr--loading').removeClass('ssc-filter-attr--loading');
                self.$wrap.find('.ssc-filter-attr .ssc-filter-cb').prop('disabled', false);
                $btn.removeClass('ssc-btn--loading');
            });
        },

        /* -------------------------------------------------------------------
           Дизейблить чекбоксы фильтров, значения которых нет у оставшихся товаров
           ------------------------------------------------------------------- */
        updateFilterAvailability: function (availableFilters) {
            var self = this;
            // Для каждого атрибута проходим по всем чекбоксам
            this.$wrap.find('.ssc-filter-attr').each(function () {
                var $attrBlock = $(this);
                var attr = $attrBlock.data('attr');
                var available = (availableFilters[attr] && Array.isArray(availableFilters[attr])) ? availableFilters[attr] : null;
                // Если available === null — атрибута нет в ответе, не трогаем
                // Если available === [] — атрибут не применим к этим товарам, активируем все чекбоксы обратно
                if (available === null) return;

                $attrBlock.find('.ssc-filter-check').each(function () {
                    var $cb = $(this);
                    var $input = $cb.find('input.ssc-filter-cb');
                    var val = $input.val();
                    if (available.length > 0 && available.indexOf(val) === -1) {
                        // Значение недоступно — дизейблим
                        $cb.addClass('ssc-filter-check--disabled');
                        $input.prop('disabled', true);
                    } else {
                        // Значение доступно (или массив пуст — нет ограничений) — активируем
                        $cb.removeClass('ssc-filter-check--disabled');
                        $input.prop('disabled', false);
                    }
                });
            });
        },

        /* -------------------------------------------------------------------
           Товар выбран → подставить ширину и длину рулона (режим категории)
           ------------------------------------------------------------------- */
        onProductSelected: function (product) {
            var self = this;
            this.product    = product;
            this.rollLength = product.defaultLength || product.length || 0;

            // Перерисовать список ширин из данных товара
            var $widthList = this.$wrap.find('#ssc-width-' + this.calcId);
            if ($widthList.length && product.widths && product.widths.length) {
                var html = '';
                product.widths.forEach(function (w, i) {
                    html += '<label class="ssc-radio-btn' + (i === 0 ? ' ssc-radio-btn--active' : '') + '">' +
                        '<input type="radio" name="ssc_width_' + self.calcId + '" value="' + w + '"' + (i === 0 ? ' checked' : '') + '>' +
                        w + ' м</label>';
                });
                $widthList.html(html).addClass('ssc-width-list--has-data');
                this.rollWidth = product.widths[0] || 0;
                // Показать label
                this.$wrap.find('#ssc-roll-label-' + this.calcId).show();
                // Скрыть placeholder
                $widthList.find('.ssc-placeholder').hide();
            }

            // Список длин
            var $lenWrap = this.$wrap.find('.ssc-length-field');
            if ($lenWrap.length) {
                $lenWrap.show();
                this.$wrap.find('#ssc-length-label-' + this.calcId).show();
                if (product.lengths && product.lengths.length > 1) {
                    var lhtml = '';
                    product.lengths.forEach(function (l, i) {
                        lhtml += '<label class="ssc-radio-btn' + (i === 0 ? ' ssc-radio-btn--active' : '') + '">' +
                            '<input type="radio" name="ssc_length_' + self.calcId + '" value="' + l + '"' + (i === 0 ? ' checked' : '') + '>' +
                            l + ' м</label>';
                    });
                    this.$wrap.find('#ssc-length-' + this.calcId).html(lhtml);
                } else {
                    var $lenEl = this.$wrap.find('#ssc-length-' + this.calcId);
                    if ($lenEl.is('span')) {
                        $lenEl.text(this.rollLength + ' м');
                    }
                }
                this.$wrap.find('#ssc-length-input-' + this.calcId).val(this.rollLength);
            }

            this.$wrap.find('.ssc-step--roll').addClass('ssc-step--active');
            this.$wrap.find('.ssc-step--dims').addClass('ssc-step--active');
            this.$wrap.find('.ssc-form-product-name').val(product.name || '');

            // Закрываем popup с товарами с небольшой задержкой
            var self2 = this;
            setTimeout(function () {
                $.magnificPopup.close();
            }, 100);

            this.calculate();
        },

        /* -------------------------------------------------------------------
           Расчёт (формулы из trava2 calculator-js.js)
           ------------------------------------------------------------------- */
        calculate: function () {
            var L  = this.areaLen;   // Длина площадки
            var W  = this.areaWid;   // Ширина площадки
            var rW = this.rollWidth;  // Ширина рулона
            var rL = this.rollLength; // Длина рулона

            this.$wrap.find('.ssc-area-result').text(L && W ? Math.round(L * W) : 0);

            if (!L || !W || !rW || !rL) {
                this.drawCanvas();
                return;
            }

            var area = L * W;

            /* --- Разметка поля (формулы из trava2) ---
               markupCount  — суммарная длина линий разметки (м.п.)
               markupArea   — площадь материала разметки с запасом 3% (м²), ceil */
            var markupType  = this.$wrap.find('input[name="ssc_markup_type_' + this.calcId + '"]:checked').val() || 'none';
            var markupCount = 0;
            var markupArea  = 0;
            if (this.config.markupEnabled && markupType !== 'none') {
                var rawMarkup = 0;
                if (markupType === 'football') {
                    markupCount = L * 2 + W * 3 + 314;
                    rawMarkup   = markupCount * 0.10;
                } else if (markupType === 'mini-football') {
                    markupCount = L * 2 + W * 3 + 65;
                    rawMarkup   = markupCount * 0.08;
                } else if (markupType === 'tennis') {
                    markupCount = L * 4 + W * 2 + W + 1.73 + (W - 2.74) * 2 + 12.85;
                    rawMarkup   = markupCount * 0.05;
                } else if (markupType === 'hockey') {
                    markupCount = L * 2 + W * 5 + 121;
                    rawMarkup   = markupCount * 0.075;
                }
                markupArea = Math.ceil(rawMarkup * 1.03); // 3% подрез, округление вверх
            }

            /* --- Количество рулонов (шахматный раскрой, включая материал разметки) ---
               Общий объём материала = площадь поля + площадь материала разметки */
            var totalMaterialArea = area + markupArea;
            var rollCount = Math.ceil(totalMaterialArea / (rW * rL));

            /* --- Горизонтальные стыки (между полосами по ширине) ---
               stripsCount = ceil(W / rW)
               Стыков на 1 меньше, чем полос */
            var stripsCount  = Math.ceil(W / rW);
            var hSeamsCount  = stripsCount - 1;
            var hSeamLen     = hSeamsCount * L;

            /* --- Вертикальные стыки (шахматный порядок) ---
               Нечётные полосы: первый шов на rL, затем через rL
               Чётные полосы: первый шов на rL/2, затем через rL */
            var styk_odd = 0, styk_even = 0, xi;
            if (rL < L) {
                xi = rL;
                while (xi < L) { styk_odd++;  xi += rL; }
                xi = rL / 2;
                while (xi < L) { styk_even++; xi += rL; }
            }

            var oddStripsCount  = Math.ceil(stripsCount / 2);
            var evenStripsCount = Math.floor(stripsCount / 2);
            var totalStyk  = oddStripsCount * styk_odd + evenStripsCount * styk_even;
            var vSeamLen   = totalStyk * rW;

            var totalSeamLen = hSeamLen + vSeamLen;

            /* --- Клей и шовная лента с учётом длины линий разметки ---
               Шовная лента и клей клеятся и на швы рулонов, и вдоль линий разметки */
            var effectiveSeamLen = totalSeamLen + markupCount;
            var glueKg    = effectiveSeamLen * 0.5 * 1.05;
            var glueCount = Math.ceil(glueKg / 10);
            var tapeMeters = effectiveSeamLen * 1.05;

            /* --- Кварцевый песок и резиновая крошка (кг/м²) ---
               Таблица из trava2: зависит от высоты ворса товара */
            var h = this.product ? (this.product.height || 0) : 0;
            var sandKg   = Math.round(area * this._sandDensity(h));
            var rubberKg = Math.round(area * this._rubberDensity(h));

            /* --- Стоимости --- */
            var price      = this.product ? (this.product.price || 0) : 0;
            // Материал разметки — тот же продукт, площадь добавляется к основной
            var totalGrassArea = area + markupArea;
            var grassCost  = totalGrassArea * price;
            var glueCost   = glueCount * (this.config.gluePrice || 4000);
            var tapeCost   = tapeMeters * (this.config.tapePrice || 65);
            var sandCost   = (sandKg / 1000) * (this.config.sandPrice || 3950);
            var rubberCost = (rubberKg / 1000) * (this.config.rubberPrice || 24500);

            var result = {
                area:            area,
                markupArea:      markupArea,
                totalGrassArea:  totalGrassArea,
                rollCount:       rollCount,
                stripsCount:     stripsCount,
                hSeamsCount:     hSeamsCount,
                totalStyk:       totalStyk,
                totalSeamLen:    totalSeamLen,
                markupType:      markupType,
                markupCount:     markupCount,
                glueCount:       glueCount,
                glueKgDisplay:   glueCount * 10,
                tapeMeters:      tapeMeters,
                sandKg:          sandKg,
                rubberKg:        rubberKg,
                grassCost:       grassCost,
                glueCost:        glueCost,
                tapeCost:        tapeCost,
                sandCost:        sandCost,
                rubberCost:      rubberCost
            };

            this._lastCalc = result;
            this.updateResultsUI(result);
            this.updateTotals(result);
            this.drawCanvas();
        },

        /* -------------------------------------------------------------------
           Плотность насыпки по высоте ворса (кг/м²)
           Точная таблица из trava2 calculator-js.js
           Результат в кг/м², для перевода в тонны делить на 1000.
           ------------------------------------------------------------------- */
        _sandDensity: function (h) {
            if (h >= 10 && h <= 12) return 7.8;
            if (h >= 14 && h <= 15) return 10;
            if (h == 20) return 4.8;
            if (h == 25) return 6;
            if (h == 30) return 7.5;
            if (h >= 32 && h <= 35) return 9;
            if (h == 40) return 12;
            if (h == 45) return 20;
            if (h == 50) return 22;
            if (h == 55) return 22;
            if (h == 60) return 22;
            return 0;
        },
        _rubberDensity: function (h) {
            if (h < 20) return 0;
            if (h == 20) return 3;
            if (h == 25) return 4;
            if (h == 30) return 5;
            if (h >= 32 && h <= 35) return 6;
            if (h == 40) return 7;
            if (h == 45) return 8;
            if (h == 50) return 9;
            if (h == 55) return 10.5;
            if (h == 60) return 12;
            return 0;
        },

        /* -------------------------------------------------------------------
           Обновить UI результатов
           ------------------------------------------------------------------- */
        updateResultsUI: function (res) {
            var $r = this.$wrap.find('#ssc-results-' + this.calcId);
            // Площадь: если есть разметка — показываем итоговую + расшифровку
            var hasMarkup = res.markupType && res.markupType !== 'none' && res.markupArea > 0;
            if (hasMarkup) {
                $r.find('.ssc-res-area').text(Math.round(res.totalGrassArea) + ' м² (' + Math.round(res.area) + ' + ' + res.markupArea + ' разметка)');
            } else {
                $r.find('.ssc-res-area').text(Math.round(res.area) + ' м²');
            }
            $r.find('.ssc-res-rolls').text(res.rollCount + ' шт');
            $r.find('.ssc-res-seams').text(res.totalSeamLen.toFixed(1) + ' м.п. (гор.: ' + res.hSeamsCount + ' шв., верт.: ' + res.totalStyk + ' шв.)');
            if (res.markupCount > 0) {
                $r.find('.ssc-res-seams-markup').text(res.markupCount.toFixed(1) + ' м.п.');
                $r.find('.ssc-res-row-markup-seams').show();
            } else {
                $r.find('.ssc-res-row-markup-seams').hide();
            }
            $r.find('.ssc-res-glue').text(res.glueCount + ' банок - ' + res.glueKgDisplay + ' кг (~' + this._fmt(res.glueCost) + ' руб.)');
            $r.find('.ssc-res-tape').text(res.tapeMeters.toFixed(1) + ' м.п. в т.ч. + 5% на подрез (~' + this._fmt(res.tapeCost) + ' руб.)');
            $r.find('.ssc-res-sand').text(res.sandKg + ' кг (~' + this._fmt(res.sandCost) + ' руб.)');
            $r.find('.ssc-res-rubber').text(res.rubberKg + ' кг (~' + this._fmt(res.rubberCost) + ' руб.)');

            this.$wrap.find('.ssc-step--results').addClass('ssc-step--active');
            this.syncCheckboxRows();
        },

        /* -------------------------------------------------------------------
           Показать/скрыть ssc-result-val в строках с чекбоксами
           ------------------------------------------------------------------- */
        syncCheckboxRows: function () {
            var pairs = [
                { check: '.ssc-glue-check',   val: '.ssc-res-glue'   },
                { check: '.ssc-tape-check',   val: '.ssc-res-tape'   },
                { check: '.ssc-sand-check',   val: '.ssc-res-sand'   },
                { check: '.ssc-rubber-check', val: '.ssc-res-rubber' }
            ];
            var self = this;
            pairs.forEach(function (p) {
                var checked = self.$wrap.find(p.check).is(':checked');
                self.$wrap.find(p.val).toggle(checked);
            });
        },

        updateTotals: function (res) {
            if (!res) return;
            var total = res.grassCost;
            if (this.$wrap.find('.ssc-glue-check').is(':checked'))   total += res.glueCost;
            if (this.$wrap.find('.ssc-tape-check').is(':checked'))   total += res.tapeCost;
            if (this.$wrap.find('.ssc-sand-check').is(':checked'))   total += res.sandCost;
            if (this.$wrap.find('.ssc-rubber-check').is(':checked')) total += res.rubberCost;

            this.$wrap.find('.ssc-res-total').text(this._fmt(total) + ' руб.');

            // Скрытые поля формы
            this.$wrap.find('.ssc-form-area').val(Math.round(res.area) + ' м²');
            this.$wrap.find('.ssc-form-rolls').val(res.rollCount + ' шт');
            this.$wrap.find('.ssc-form-seams').val(res.totalSeamLen.toFixed(1) + ' м.п.');
            this.$wrap.find('.ssc-form-glue').val(res.glueCount + ' банок (' + res.glueKgDisplay + ' кг)');
            this.$wrap.find('.ssc-form-tape').val(res.tapeMeters.toFixed(1) + ' м.п.');
            this.$wrap.find('.ssc-form-total').val(this._fmt(total));
        },

        _fmt: function (n) {
            return Math.round(n).toLocaleString('ru-RU');
        },

        /* -------------------------------------------------------------------
           Отрисовка canvas — шахматная раскладка рулонов
           ------------------------------------------------------------------- */
        drawCanvas: function () {
            if (!this.ctx) return;
            var canvas = this.$canvas[0];
            var CW     = canvas.width;
            var CH     = canvas.height;
            var ctx    = this.ctx;

            ctx.clearRect(0, 0, CW, CH);

            var L  = this.areaLen;
            var Aw = this.areaWid;
            var rW = this.rollWidth;
            var rL = this.rollLength;

            if (!L || !Aw || !rW || !rL) return;

            // Масштаб: ось X = длина площадки (L), ось Y = ширина площадки (Aw)
            var scaleX = CW / L;
            var scaleY = CH / Aw;

            var stripsCount = Math.ceil(Aw / rW);
            ctx.lineWidth   = 1.5;
            ctx.strokeStyle = '#ffff00';

            for (var s = 0; s < stripsCount; s++) {
                var y0 = Math.round(s * rW * scaleY);
                var y1 = Math.round(Math.min((s + 1) * rW, Aw) * scaleY);
                var isOdd = (s % 2 === 0); // 0-indexed: чётный индекс = нечётная полоса

                // Чередующийся фон полос
                ctx.fillStyle = isOdd ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
                ctx.fillRect(0, y0, CW, y1 - y0);

                // Горизонтальная линия — шов между полосами
                if (s > 0) {
                    ctx.strokeStyle = 'rgba(255,220,0,0.9)';
                    ctx.lineWidth   = 2;
                    ctx.setLineDash([6, 3]);
                    ctx.beginPath();
                    ctx.moveTo(0, y0);
                    ctx.lineTo(CW, y0);
                    ctx.stroke();
                }

                // Вертикальные швы — шахматный сдвиг (только если рулон короче площадки)
                if (rL < L) {
                    var xStart = isOdd ? rL * scaleX : (rL / 2) * scaleX;
                    var xi = xStart;
                    ctx.strokeStyle = 'rgba(255,220,0,0.7)';
                    ctx.lineWidth   = 1.5;
                    ctx.setLineDash([4, 4]);
                    while (xi < CW) {
                        ctx.beginPath();
                        ctx.moveTo(Math.round(xi), y0);
                        ctx.lineTo(Math.round(xi), y1);
                        ctx.stroke();
                        xi += rL * scaleX;
                    }
                }
            }

            ctx.setLineDash([]);

            // Контур площадки
            ctx.strokeStyle = 'rgba(255,255,255,0.8)';
            ctx.lineWidth   = 2;
            ctx.strokeRect(0, 0, CW, CH);

            // Подписи
            ctx.fillStyle   = '#fff';
            ctx.font        = 'bold 13px sans-serif';
            ctx.shadowColor = 'rgba(0,0,0,0.6)';
            ctx.shadowBlur  = 4;
            ctx.textAlign   = 'left';
            ctx.fillText('Длина: ' + L + ' м', 8, CH - 8);
            ctx.textAlign   = 'right';
            ctx.fillText('Ширина: ' + Aw + ' м', CW - 8, CH - 8);
            ctx.textAlign   = 'left';
            ctx.shadowBlur  = 0;
        },

        /* -------------------------------------------------------------------
           Модальное окно КП
           ------------------------------------------------------------------- */
        openModal: function () {
            var res = this._lastCalc;
            if (!res || !res.area) {
                this.$wrap.find('.ssc-kp-error').show();
                return;
            }
            this.$wrap.find('.ssc-kp-error').hide();
            this.$wrap.find('#ssc-modal-' + this.calcId).fadeIn(200);
            $('body').addClass('ssc-modal-open');
        },

        closeModal: function () {
            this.$wrap.find('#ssc-modal-' + this.calcId).fadeOut(200);
            $('body').removeClass('ssc-modal-open');
        },

        /* -------------------------------------------------------------------
           Отправка формы + генерация PDF
           ------------------------------------------------------------------- */
        submitKP: function ($form) {
            var self = this;
            var $btn = $form.find('.ssc-submit-btn');

            $btn.prop('disabled', true).text(g.strings.sending);

            var formData = $form.serialize() + '&action=ssc_send_kp';
            $.post(g.ajaxUrl, formData, function () {
                $form.find('.ssc-form-success').show();
                $btn.hide();
                self.generatePDF($form);
            }).fail(function () {
                $btn.prop('disabled', false).text('Скачать КП (PDF)');
            });
        },

        /* -------------------------------------------------------------------
           Генерация PDF через pdfMake
           ------------------------------------------------------------------- */
        generatePDF: function ($form) {
            var self   = this;
            var res    = this._lastCalc;
            var config = this.config;
            var date   = config.siteDate || '';
            var company = config.companyName || window.location.hostname;

            // Поддержка вызова без формы (тестовая кнопка)
            var clientName  = '', clientPhone = '', clientEmail = '', productName = '';
            var $calc = this.$wrap;

            if ($form && $form.length) {
                clientName  = $form.find('[name="client_name"]').val();
                clientPhone = $form.find('[name="client_phone"]').val();
                clientEmail = $form.find('[name="client_email"]').val();
                productName = $form.find('.ssc-form-product-name').val();
                $calc = $form.closest('.ssc-calculator');
            }

            var total = res.grassCost;
            if ($calc.find('.ssc-glue-check').is(':checked'))   total += res.glueCost;
            if ($calc.find('.ssc-tape-check').is(':checked'))   total += res.tapeCost;
            if ($calc.find('.ssc-sand-check').is(':checked'))   total += res.sandCost;
            if ($calc.find('.ssc-rubber-check').is(':checked')) total += res.rubberCost;
            if ($calc.find('.ssc-markup-check').is(':checked')) total += res.markupCost;

            var canvasDataUrl = self.$canvas.length ? self.$canvas[0].toDataURL('image/png') : null;

            var tableBody = [
                [{ text: 'Параметр', bold: true, fillColor: '#f0f6ff' }, { text: 'Значение', bold: true, fillColor: '#f0f6ff' }],
                ['Покрытие', productName || '—'],
                ['Площадь', res.totalGrassArea > res.area ? Math.round(res.totalGrassArea) + ' м² (поле ' + Math.round(res.area) + ' + разметка ' + res.markupArea + ')' : Math.round(res.area) + ' м²'],
                ['Количество рулонов', res.rollCount + ' шт'],
                ['Горизонтальных стыков', res.hSeamsCount + ' шт'],
                ['Вертикальных стыков', res.totalStyk + ' шт'],
                ['Длина швов (всего)', res.totalSeamLen.toFixed(1) + ' м.п.'],
                ['Клей', res.glueCount + ' банок (' + res.glueKgDisplay + ' кг)  ≈ ' + self._fmt(res.glueCost) + ' руб.'],
                ['Шовная лента', res.tapeMeters.toFixed(1) + ' м.п.  ≈ ' + self._fmt(res.tapeCost) + ' руб.'],
            ];

            if (config.sandEnabled && res.sandKg) {
                tableBody.push(['Кварцевый песок', res.sandKg + ' кг  ≈ ' + self._fmt(res.sandCost) + ' руб.']);
            }
            if (config.rubberEnabled && res.rubberKg) {
                tableBody.push(['Резиновая крошка', res.rubberKg + ' кг  ≈ ' + self._fmt(res.rubberCost) + ' руб.']);
            }
            if (config.markupEnabled && res.markupType && res.markupType !== 'none' && res.markupArea > 0) {
                var markupLabels = { football: 'Футбол', 'mini-football': 'Мини-футбол', tennis: 'Теннис', hockey: 'Хоккей' };
                tableBody.push(['Тип разметки', markupLabels[res.markupType] || res.markupType]);
                tableBody.push(['Длина линий разметки', res.markupCount.toFixed(1) + ' м.п.']);
                tableBody.push(['Материал разметки (+3% подрез)', res.markupArea + ' м²  ≈ ' + self._fmt(res.markupCost) + ' руб.']);
            }
            tableBody.push([{ text: 'ИТОГО', bold: true }, { text: self._fmt(total) + ' руб.', bold: true, color: '#2271b1' }]);

            var content = [
                {
                    columns: [
                        { text: company, style: 'companyName', width: '*' },
                        { text: date, style: 'dateText', alignment: 'right', width: 'auto' }
                    ],
                    marginBottom: 12
                },
                { text: 'КОММЕРЧЕСКОЕ ПРЕДЛОЖЕНИЕ', style: 'header' },
                { text: 'Расчёт стоимости покрытия', style: 'subheader' },
                { canvas: [{ type: 'line', x1: 0, y1: 0, x2: 515, y2: 0, lineColor: '#2271b1', lineWidth: 2 }], margin: [0, 0, 0, 16] },
            ];

            if (canvasDataUrl) {
                content.push({
                    image: canvasDataUrl,
                    width: 515,
                    margin: [0, 0, 0, 16],
                    alignment: 'center'
                });
            }

            content.push({
                table: {
                    widths: ['*', '*'],
                    body: tableBody
                },
                layout: {
                    hLineWidth: function () { return 0.5; },
                    vLineWidth: function () { return 0.5; },
                    hLineColor: function () { return '#ddd'; },
                    vLineColor: function () { return '#ddd'; },
                    fillColor: function (rowIndex) { return rowIndex % 2 === 0 ? null : '#f9f9f9'; }
                },
                margin: [0, 0, 0, 20]
            });

            content.push(
                { canvas: [{ type: 'line', x1: 0, y1: 0, x2: 515, y2: 0, lineColor: '#ddd', lineWidth: 1 }], margin: [0, 0, 0, 10] },
                { text: 'Данные заявителя:', style: 'sectionTitle', margin: [0, 0, 0, 6] },
                { text: 'Имя: ' + clientName, fontSize: 11, margin: [0, 0, 0, 3] },
                { text: 'Телефон: ' + clientPhone, fontSize: 11, margin: [0, 0, 0, 3] },
                { text: 'Email: ' + clientEmail, fontSize: 11, margin: [0, 0, 0, 12] },
                {
                    text: 'Данное коммерческое предложение является предварительным. Окончательная стоимость уточняется у менеджера.',
                    fontSize: 9,
                    color: '#888',
                    italics: true
                }
            );

            var docDef = {
                pageSize: 'A4',
                pageMargins: [30, 40, 30, 40],
                content: content,
                styles: {
                    companyName: { fontSize: 14, bold: true, color: '#1d2327' },
                    dateText: { fontSize: 11, color: '#666' },
                    header: { fontSize: 20, bold: true, color: '#2271b1', margin: [0, 0, 0, 4] },
                    subheader: { fontSize: 13, color: '#444', margin: [0, 0, 0, 8] },
                    sectionTitle: { fontSize: 12, bold: true, color: '#1d2327' }
                },
                defaultStyle: {
                    font: 'Roboto',
                    fontSize: 11,
                    color: '#1d2327'
                }
            };

            if (window.pdfMake) {
                pdfMake.createPdf(docDef).download('kp-' + (productName || 'raschet') + '.pdf');
            }
        }
    };

    /* =========================================================================
       Инициализация всех калькуляторов на странице
       ========================================================================= */
    $(document).ready(function () {
        $('.ssc-calculator').each(function () {
            new SSCInstance($(this));
        });

        $(document).on('keydown', function (e) {
            if (e.key === 'Escape') {
                $('.ssc-modal:visible').fadeOut(200);
                $('body').removeClass('ssc-modal-open');
            }
        });
    });

    $('<style>.ssc-modal-open { overflow: hidden; }</style>').appendTo('head');

}(jQuery));
